namespace PluralsightWinFormsDemoApp
{
    class SettingsCommand : CommandBase
    {
        public SettingsCommand()
        {
            Icon = IconResources.settings_icon_32;
            ToolTip = "Settings";
        }

        public override void Execute()
        {
            // not yet implemented
        }
    }
}